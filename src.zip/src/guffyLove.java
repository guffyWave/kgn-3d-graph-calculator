
/**
 *
 * @author guffy roX
 */
import java.applet.Applet;
import java.awt.Button;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.Choice;
import java.awt.Font;
import java.awt.Point;
import java.awt.Scrollbar;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.ConcurrentModificationException;

import java.awt.Label;
import java.util.ArrayList;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import java.lang.Thread.State;

/**
 *
 * @author guffy roX
 */
public class guffyLove extends Applet implements MouseListener, MouseMotionListener,
        AdjustmentListener, ActionListener, ItemListener {

    int width, height;
    int longitudnalMovement, horizontalMovement;
    int mx, my;  // the most recently recorded mouse coordinates
    Scrollbar vertSB, horzSB;
    //scroll bars for background coclor
    Scrollbar backR, backG, backB;
    Scrollbar foreR, foreG, foreB;
    Scrollbar longiBar, horizBar;
    boolean isCloud;
    int backColRed;
    int backColGreen;
    int backColBlue;
    int foreColRed;
    int foreColGreen;
    int foreColBlue;
    TextField tf = new TextField("0");
    Button bt = new Button("Draw");
    Button btPlay = new Button("Play");
    Button btPause = new Button("Pause");
    Button btMonoChrome = new Button("Mono Chrome");
    Button btCloud = new Button("Cloud");
    Button btWave = new Button("Wave");
    TextField lb = new TextField();
    int andar = 100;
    int eye = 30;
    Rotator rt = new Rotator();
    Image backbuffer;
    Graphics backg;
    int azimuth = 48, elevation = 29;
    // Point3D[] vertices;
    ArrayList<Point3D> verticesList = new ArrayList<Point3D>();
    ArrayList<Edge> edgeList = new ArrayList<Edge>();
    double maxRange = 10.0;
    Calendar clndr;
    String formula = "0";
    boolean isMonoChrome = false;
    boolean iswave = false;
    SineWaveGenerator sinWave;
    double[] arrayY;
    Choice xFrom, xTo, zFrom, zTo, desnsityChoice;
    double valxFrom = -5.0, valxTo = 5.0, valzFrom = -5.0, valzTo = 5.0, valdesnsityChoice = 1.0;
    
   

//public double findY(double x,double z){
//return (7+x)*((2*z)+3);
    //return  ((x*x)-(z*z)) ;
//return Math.cos(x)+Math.sin(z);
    //return Math.cbrt(z*x)+Math.cbrt(x*z);
//return Math.sqrt((x*x)-(z*z));
//return Math.sqrt(x+z);
//return x+4
//Math.sin(x)*z+Math.cos(z);
//return 0;
//pow(x,sin(z))
//Math.pow(Math.cos(x)+Math.sin(z),2)+(z-x)
//return Math.cosh(z*z)+Math.cbrt(x*z);   
    // return ((x*x)+(z*z))*((x*x)+(z*z))  ; 
//return Math.cos(Math.abs(x)+Math.abs(z))*(Math.abs(x)+Math.abs(z))   ;
//return Math.sinh(x)+Math.cbrt(z);
//return Math.tanh(x)+Math.sinh(z)+Math.cosh(z);
// return Math.signum(x)+Math.signum(z);
//return Math.hypot(x, z);
    //return Math.max(x, z);
//return Math.atan2(x, z);
//x+z+Math.cos(x*z)
//x*Math.cos(z)
//(x*x)/(z*z)
//x*(Math.cos(z)+Math.cos(x))
//x*Math.cos(z+x)
//Math.pow(Math.cos(x)+Math.sin(z),2)+(z-x)*x
//Math.pow(Math.cos(x)+Math.sin(z),2)
//return Math.expm1(x)+Math.expm1(z);
// }
    public boolean checkEdge(Point3D a, Point3D b) {
        Edge e = new Edge(a, b);
        boolean isEdge = false;

        if (edgeList.contains(e)) {
            isEdge = true;
        }

        return isEdge;
    }

    public void createEdge(Point3D m, Point3D n) {
        if (!checkEdge(m, n)) {
            Edge e = new Edge(m, n);
            edgeList.add(e);

        }

    }

    public void createAxis() {


        Point3D axisX1 = new Point3D(15, 0, 0);
        verticesList.add(axisX1);
        Point3D axisX2 = new Point3D(-15, 0, 0);
        verticesList.add(axisX2);
        Point3D axisY1 = new Point3D(0, 15, 0);
        verticesList.add(axisY1);
        Point3D axisY2 = new Point3D(0, -15, 0);
        verticesList.add(axisY2);
        Point3D axisZ1 = new Point3D(0, 0, 15);
        verticesList.add(axisZ1);
        Point3D axisZ2 = new Point3D(0, 0, -15);
        verticesList.add(axisZ2);

        Edge eX = new Edge(axisX1, axisX2);
        edgeList.add(eX);
        Edge eY = new Edge(axisY1, axisY2);
        edgeList.add(eY);
        Edge eZ = new Edge(axisZ1, axisZ2);
        edgeList.add(eZ);

    }

    public void init() {
        width = getSize().width;
        height = getSize().height;
        setLayout(null);

        longitudnalMovement = 0;
        horizontalMovement = 0;



        clndr = Calendar.getInstance();

        Font f = new Font(Font.DIALOG_INPUT, Font.PLAIN, 15);
        setFont(f);

        foreColRed = 100;
        foreColGreen = 100;
        foreColBlue = 100;



        createAxis();

        System.gc();

        backbuffer = createImage(width, height);
        backg = backbuffer.getGraphics();
        drawWireframe(backg);

        rt.start();

        addMouseListener(this);
        addMouseMotionListener(this);
        bt.addActionListener(this);
        btPlay.addActionListener(this);
        btPause.addActionListener(this);
        btMonoChrome.addActionListener(this);
        btCloud.addActionListener(this);
        btWave.addActionListener(this);

        vertSB = new Scrollbar(Scrollbar.VERTICAL, 20, 50, 20, 100);

        horzSB = new Scrollbar(Scrollbar.HORIZONTAL, 1, 1, 30, 60);

        backR = new Scrollbar(Scrollbar.HORIZONTAL, 0, 5, 0, 255);
        backG = new Scrollbar(Scrollbar.HORIZONTAL, 0, 5, 0, 255);
        backB = new Scrollbar(Scrollbar.HORIZONTAL, 0, 5, 0, 255);

        foreR = new Scrollbar(Scrollbar.HORIZONTAL, 100, 0, 0, 255);
        foreG = new Scrollbar(Scrollbar.HORIZONTAL, 100, 0, 0, 255);
        foreB = new Scrollbar(Scrollbar.HORIZONTAL, 100, 0, 0, 255);

        longiBar = new Scrollbar(Scrollbar.VERTICAL, 0, 0, -200, 200);
        horizBar = new Scrollbar(Scrollbar.HORIZONTAL, 0, 0, -200, 200);

        xFrom = new Choice();
        xFrom.add("-10.0");
        xFrom.add("-9.0");
        xFrom.add("-8.0");
        xFrom.add("-7.0");
        xFrom.add("-6.0");
        xFrom.add("-4.0");
        xFrom.add("-3.0");
        xFrom.add("-2.0");
        xFrom.add("-1.0");
        xFrom.add("0.0");
        xFrom.add("1.0");
        xFrom.add("2.0");
        xFrom.add("3.0");
        xFrom.add("4.0");
        xFrom.add("5.0");
        xFrom.add("6.0");
        xFrom.add("7.0");
        xFrom.add("8.0");
        xFrom.add("9.0");
        xFrom.add("10.0");


        xTo = new Choice();
        xTo.add("1.0");
        xTo.add("2.0");
        xTo.add("3.0");
        xTo.add("4.0");
        xTo.add("5.0");
        xTo.add("6.0");
        xTo.add("7.0");
        xTo.add("8.0");
        xTo.add("9.0");
        xTo.add("10.0");
        xTo.add("-10.0");
        xTo.add("-9.0");
        xTo.add("-8.0");
        xTo.add("-7.0");
        xTo.add("-6.0");
        xTo.add("-4.0");
        xTo.add("-3.0");
        xTo.add("-2.0");
        xTo.add("-1.0");
        xTo.add("0.0");



        zFrom = new Choice();
        zFrom.add("-10.0");
        zFrom.add("-9.0");
        zFrom.add("-8.0");
        zFrom.add("-7.0");
        zFrom.add("-6.0");
        zFrom.add("-4.0");
        zFrom.add("-3.0");
        zFrom.add("-2.0");
        zFrom.add("-1.0");
        zFrom.add("0.0");
        zFrom.add("1.0");
        zFrom.add("2.0");
        zFrom.add("3.0");
        zFrom.add("4.0");
        zFrom.add("5.0");
        zFrom.add("6.0");
        zFrom.add("7.0");
        zFrom.add("8.0");
        zFrom.add("9.0");
        zFrom.add("10.0");

        zTo = new Choice();
        zTo.add("1.0");
        zTo.add("2.0");
        zTo.add("3.0");
        zTo.add("4.0");
        zTo.add("5.0");
        zTo.add("6.0");
        zTo.add("7.0");
        zTo.add("8.0");
        zTo.add("9.0");
        zTo.add("10.0");
        zTo.add("-10.0");
        zTo.add("-9.0");
        zTo.add("-8.0");
        zTo.add("-7.0");
        zTo.add("-6.0");
        zTo.add("-4.0");
        zTo.add("-3.0");
        zTo.add("-2.0");
        zTo.add("-1.0");
        zTo.add("0.0");


        desnsityChoice = new Choice();
        desnsityChoice.add("Low");
        desnsityChoice.add("High");


      


        add(vertSB);
        add(horzSB);
        add(tf);
        add(bt);
        add(btPlay);
        add(btPause);
        add(btMonoChrome);
        add(btCloud);
        add(btWave);

        add(lb);
        add(backR);
        add(backG);
        add(backB);

        add(foreR);
        add(foreG);
        add(foreB);

        add(longiBar);
        add(horizBar);

        add(xFrom);
        add(xTo);
        add(zFrom);
        add(zTo);
        add(desnsityChoice);

        

        vertSB.setBounds(width - 30, 40, 20, 100);
        horzSB.setBounds(width - 100, 5, 50, 20);

        tf.setBounds(70, 30, 200, 20);
        bt.setBounds(300, 30, 80, 20);

        btPlay.setBounds((width / 2) - 300, height - 70, 50, 20);
        btPause.setBounds((width / 2) - 300 + 50 + 20, height - 70, 50, 20);

        btMonoChrome.setBounds((width / 2) - 300 + 50 + 20 + 50 + 20, height - 70, 110, 20);
        btCloud.setBounds((width / 2) - 300 + 50 + 20 + 50 + 20 + 80 + 40, height - 70, 80, 20);
        btWave.setBounds((width / 2) - 300 + 50 + 20 + 50 + 20 + 80 + 40 + 80 + 20, height
                - 70, 80, 20);

        lb.setBounds((width / 2) - 300, height - 40, width / 2, 20);

        backR.setBounds(width - 80, height - 100, 70, 20);
        backG.setBounds(width - 80, height - 70, 70, 20);
        backB.setBounds(width - 80, height - 40, 70, 20);


        foreR.setBounds(width - 200, height - 100, 100, 20);
        foreG.setBounds(width - 200, height - 70, 100, 20);
        foreB.setBounds(width - 200, height - 40, 100, 20);

        longiBar.setBounds(5, height - 150, 20, 100);
        horizBar.setBounds(15, height - 40, 100, 20);

        xFrom.setBounds(5 + 20, height / 2, 50, 20);
        xTo.setBounds(120, height / 2, 50, 20);
        zFrom.setBounds(5 + 20, height / 2 + 30, 50, 20);
        zTo.setBounds(120, height / 2 + 30, 50, 20);
        desnsityChoice.setBounds(80, height / 2 + 70, 70, 20);

       


        vertSB.addAdjustmentListener(this);
        horzSB.addAdjustmentListener(this);
        backR.addAdjustmentListener(this);
        backG.addAdjustmentListener(this);
        backB.addAdjustmentListener(this);

        foreR.addAdjustmentListener(this);
        foreG.addAdjustmentListener(this);
        foreB.addAdjustmentListener(this);

        longiBar.addAdjustmentListener(this);
        horizBar.addAdjustmentListener(this);


        vertSB.setValue(andar);
        horzSB.setValue(eye);

        xFrom.addItemListener(this);
        xTo.addItemListener(this);
        zFrom.addItemListener(this);
        zTo.addItemListener(this);
        desnsityChoice.addItemListener(this);

  
    }

    void drawWireframe(Graphics g) {
        try {
            // compute coefficients for the projection
            double theta = Math.PI * azimuth / 180.0;
            double phi = Math.PI * elevation / 180.0;
            float cosT = (float) Math.cos(theta), sinT = (float) Math.sin(theta);
            float cosP = (float) Math.cos(phi), sinP = (float) Math.sin(phi);
            float cosTcosP = cosT * cosP, cosTsinP = cosT * sinP,
                    sinTcosP = sinT * cosP, sinTsinP = sinT * sinP;


            Point[] points = new Point[verticesList.size()];



            int j = 0;
            int scaleFactor = width / andar;
            float near = eye;  //  eye to near plane dikhaegaaa
            float nearToObj = 1.5f;

            Iterator i3 = verticesList.iterator();
            while (i3.hasNext()) {


                Point3D p = (Point3D) i3.next();
                double x0 = p.x;
                double y0 = p.y;
                double z0 = p.z;

                //  orthographic projection calculate karegaaa

                double x1 = cosT * x0 + sinT * z0 + horizontalMovement;
                double y1 = -sinTsinP * x0 + cosP * y0 + cosTsinP * z0 - longitudnalMovement;

                // 3D projec. generate karega

                double z1 = cosTcosP * z0 - sinTcosP * x0 - sinP * y0;
                x1 = x1 * near / (z1 + near + nearToObj);
                y1 = y1 * near / (z1 + near + nearToObj);


                points[j] = new Point(
                        (int) (width / 2 + scaleFactor * x1 + 0.5),
                        (int) (height / 2 - scaleFactor * y1 + 0.5));



                j++;
            }

            Color cBack = new Color(backColRed, backColGreen, backColBlue);



            Graphics2D g2 = (Graphics2D) g;

            GradientPaint gp = new GradientPaint(0f, 8 * (height / 10), Color.BLACK, 0f, 0f, cBack);

            g2.setPaint(gp);


            //  g.setColor(cBack);
            g.fillRect(0, 0, width, height);
            g.setColor(Color.white);

            g.drawString("f(x,z)=", 0, 45);

            g.drawString("Status ", (width / 2) - 390, height - 25);









            g.setColor(Color.gray);
            g.drawString("KGN 3D Graph Calculator ", (width / 2) - 135, 20);
            g.drawString("Developed by Gufran Khurshid guffy1267@gmail ", (width / 2)
                    - 200, 40);

            g.drawString("Elevation  ", width - 430, 20);
            g.drawString("Azimuth  ", width - 300, 20);

            g.setColor(Color.white);
            g.drawString("" + elevation + "", width - 340, 20);
            g.drawString("" + azimuth + "", width - 210, 20);



            g.setColor(Color.gray);
            g.drawString("Colour Chooser ", width - 200, height - 120);

            g.drawString("Note:Application's performance is processor dependent.", 5, 79);
            g.drawString("Valid fuction ", 5, 105);
            g.drawString("sin,cos,tan,log ", 5, 120);
            g.drawString("|a| - abs(a) ", 5, 135);
            g.drawString("x^2 - pow(x,2) ", 5, 150);
            g.drawString("Example : cos(x)+sin(z)", 5, 190);


            g.setColor(Color.white);
            g.drawString("Settings", 5, (height / 2) - 40);
            g.setColor(Color.gray);
            g.drawString("X ", 5, height / 2 + 10);
            g.drawString("to ", 85, height / 2 + 10);
            g.drawString("Z ", 5, height / 2 + 10 + 30);
            g.drawString("to ", 85, height / 2 + 10 + 30);
            g.drawString("Density ", 5, height / 2 + 90);






            g.drawString("2D Translation", 40, height - 70);

            g.drawString("zoom", width - 45, 36);
            g.drawString("Alpha", width - 170, 20);


            System.gc();



            g.setColor(Color.white);
            Color cFore = new Color(foreColRed, foreColGreen, foreColBlue);


            Iterator i7 = edgeList.iterator();

            while (i7.hasNext()) {

                Edge e2 = (Edge) i7.next();

                Point3D p1 = e2.a;
                Point3D p2 = e2.b;

                if ((e2.a.x == 15) && (e2.b.x == -15) ) {
                    g.setColor(Color.red);
                } else if ((e2.a.y == 15) && (e2.b.y == -15) ) {
                    g.setColor(Color.green);
                } else if ((e2.a.z == 15) && (e2.b.z == -15) ) {
                    g.setColor(Color.blue);
                } else if ((e2.a.x >= -1) && (e2.a.x <= 1) && (e2.b.z >= -1) && (e2.b.z <= 1)) {
                    if (isMonoChrome == true) {
                        Color c = new Color(0, 255, 0);
                        g.setColor(c);
                    } else {
                        g.setColor(cFore);
                    }
                } else if ((e2.a.x >= -2) && (e2.a.x <= 2) && (e2.b.z >= -2) && (e2.b.z <= 2)) {
                    if (isMonoChrome == true) {
                        Color c = new Color(0, 225, 0);
                        g.setColor(c);
                    } else {
                        g.setColor(cFore);
                    }
                } else if ((e2.a.x >= -3) && (e2.a.x <= 3) && (e2.b.z >= -3) && (e2.b.z <= 3)) {
                    if (isMonoChrome == true) {
                        Color c = new Color(0, 196, 0);
                        g.setColor(c);
                    } else {
                        g.setColor(cFore);
                    }
                } else if ((e2.a.x >= -4) && (e2.a.x <= 4) && (e2.b.z >= -4) && (e2.b.z <= 4)) {
                    if (isMonoChrome == true) {
                        Color c = new Color(0, 166, 0);
                        g.setColor(c);
                    } else {
                        g.setColor(cFore);
                    }
                } else if ((e2.a.x >= -5) && (e2.a.x <= 5) && (e2.b.z >= -5) && (e2.b.z <= 5)) {
                    if (isMonoChrome == true) {
                        Color c = new Color(0, 136, 0);
                        g.setColor(c);
                    } else {
                        g.setColor(cFore);
                    }
                } else if ((e2.a.x >= -6) && (e2.a.x <= 6) && (e2.b.z >= -6) && (e2.b.z <= 6)) {
                    if (isMonoChrome == true) {
                        Color c = new Color(0, 106, 0);
                        g.setColor(c);
                    } else {
                        g.setColor(cFore);
                    }
                } else if ((e2.a.x >= -7) && (e2.a.x <= 7) && (e2.b.z >= -7) && (e2.b.z <= 7)) {
                    if (isMonoChrome == true) {
                        Color c = new Color(0, 70, 0);
                        g.setColor(c);
                    } else {
                        g.setColor(cFore);
                    }
                } else if ((e2.a.x >= -8) && (e2.a.x <= 8) && (e2.b.z >= -8) && (e2.b.z <= 8)) {
                    if (isMonoChrome == true) {
                        Color c = new Color(0, 40, 0);
                        g.setColor(c);
                    } else {
                        g.setColor(cFore);
                    }
                } else if ((e2.a.x >= -9) && (e2.a.x <= 9) && (e2.b.z >= -9) && (e2.b.z <= 9)) {
                    if (isMonoChrome == true) {
                        Color c = new Color(0, 30, 0);
                        g.setColor(c);
                    } else {
                        g.setColor(cFore);
                    }
                } else if ((e2.a.x >= -10) && (e2.a.x <= 10) && (e2.b.z >= -10) && (e2.b.z <= 10)) {
                    if (isMonoChrome == true) {
                        Color c = new Color(0, 10, 0);
                        g.setColor(c);
                    } else {
                        g.setColor(cFore);
                    }
                } else {



                    if (isMonoChrome = true) {
                        Color c = new Color(0, 2, 0);
                        g.setColor(c);
                    } else {
                        g.setColor(cFore);
                    }



                }

                Point first2DPoint = points[verticesList.indexOf(p1)];
                Point second2DPoint = points[verticesList.indexOf(p2)];


                
           
                g.drawLine(first2DPoint.x, first2DPoint.y, second2DPoint.x, second2DPoint.y);

             

               

                g.setColor(Color.white);

                if ((e2.a.z == 15) && (e2.a.y == 0)) {
                    g.drawString(" -Z", second2DPoint.x, second2DPoint.y);

                } else if ((e2.a.x == 15) && (e2.a.y == 0)) {
                    g.drawString(" -X", second2DPoint.x, second2DPoint.y);

                } else if ((e2.a.x == 0) && (e2.a.y == 15)) {
                    g.drawString("  -Y", second2DPoint.x, second2DPoint.y);
                } else if ((e2.a.x == 0) && (e2.a.z == 0)) {
                    //

                    g.drawString(".(" + e2.a.x + "," + e2.a.y + "," + e2.a.z + ")", first2DPoint.x,
                            first2DPoint.y);

                } else if ((e2.a.x == valxFrom) && (e2.a.z == valzFrom)) {


                    g.drawString(".(" + e2.a.x + "," + e2.a.y + "," + e2.a.z + ")", first2DPoint.x,
                            first2DPoint.y);


                } else if ((e2.a.x == valxFrom) && (e2.a.z == valzTo)) {
                    g.drawString(".(" + e2.a.x + "," + e2.a.y + "," + e2.a.z + ")", first2DPoint.x,
                            first2DPoint.y);
                } else if ((e2.a.x == valxTo) && (e2.a.z == valzFrom)) {
                    g.drawString(".(" + e2.a.x + "," + e2.a.y + "," + e2.a.z + ")", first2DPoint.x,
                            first2DPoint.y);
                } else if ((e2.a.x == valxTo) && (e2.a.z == valzTo)) {
                    g.drawString(".(" + e2.a.x + "," + e2.a.y + "," + e2.a.z + ")", first2DPoint.x,
                            first2DPoint.y);
                }

            }

            g.setColor(Color.black);

        } catch (ConcurrentModificationException e) {
            lb.setText(e.getMessage());
        } catch (Exception e) {
            lb.setText(e.getMessage());
        }

    }

    public void actionPerformed(ActionEvent ae) {


        rt.suspend();
        if (ae.getSource() == bt) {
            lb.setText("Drawing . . . . .. . .");
            try {
                // Thread.sleep(2000);


                btWave.setLabel("Wave");
                sinWave = new SineWaveGenerator();


                verticesList.clear();
                edgeList.clear();



                formula = tf.getText().toString().trim();

                if (formula.contains("y")) {
                    tf.setText("funtion is of x and z");
                    lb.setText("funtion is of x and z ");
                }

                if (formula.contains("sin")
                        || formula.contains("cos")
                        || formula.contains("tan")
                        || formula.contains("abs")
                        || formula.contains("acos")
                        || formula.contains("atan")
                        || formula.contains("asin")
                        || formula.contains("atan2")
                        || formula.contains("cbrt")
                        || formula.contains("ceil")
                        || formula.contains("cosh")
                        || formula.contains("sinh")
                        || formula.contains("tanh")
                        || formula.contains("exp")
                        || formula.contains("expm1")
                        || formula.contains("log")
                        || formula.contains("pow")
                        || formula.contains("random")
                        || formula.contains("round")
                        || formula.contains("sinh")
                        || formula.contains("sqrt")) {

                    formula = formula.replace("sin", "Math.sin");
                    formula = formula.replace("cos", "Math.cos");
                    formula = formula.replace("tan", "Math.tan");
                    //formula = formula.replace("sin", "Math.sin");
                    formula = formula.replace("abs", "Math.abs");
                    formula = formula.replace("asin", "Math.asin");
                    formula = formula.replace("acos", "Math.acos");
                    formula = formula.replace("atan", "Math.atan");
                    formula = formula.replace("atan2", "Math.atan2");
                    formula = formula.replace("cbrt", "Math.cbrt");
                    formula = formula.replace("sqrt", "Math.sqrt");
                    formula = formula.replace("ceil", "Math.ceil");
                    formula = formula.replace("sinh", "Math.sinh");
                    formula = formula.replace("cosh", "Math.cosh");
                    formula = formula.replace("tanh", "Math.tanh");
                    formula = formula.replace("exp", "Math.exp");
                    formula = formula.replace("expm1", "Math.expm1");
                    formula = formula.replace("log", "Math.log");
                    formula = formula.replace("pow", "Math.pow");
                    formula = formula.replace("random", "Math.random");
                    formula = formula.replace("round", "Math.round");

                }

                double d = valdesnsityChoice;
                // d = 0.5;


                for (double x = valxFrom; x <= valxTo; x = x + d) {

                    for (double z = valzFrom; z <= valzTo; z = z + d) {

                        Point3D p = new Point3D(x, guffyFormulaScriptEngine(formula, x + "", z + ""), z);
                        verticesList.add(p);

                    }

                }



                System.gc();

                Iterator i = verticesList.iterator();
                while (i.hasNext()) {
                    Point3D m = (Point3D) i.next();

                    Iterator iInner = verticesList.iterator();

                    if (isCloud) {
                        createEdge(m, m);
                    } else {
                        while (iInner.hasNext()) {
                            Point3D n = (Point3D) iInner.next();

                            if ((((m.getX() - n.getX()) == 1.00) && ((m.getZ() - n.getZ()) == 0))
                                    || (((m.getZ() - n.getZ()) == 1.00) && ((m.getX() - n.getX()) == 0))) {


                                createEdge(m, n);



                            }
                        }

                    }

                }


                createAxis();
                backbuffer = createImage(width, height);
                backg = backbuffer.getGraphics();
                drawWireframe(backg);
                repaint();





                rt.resume();

            } catch (ConcurrentModificationException e) {

                rt.suspend();
                lb.setText(e.getMessage());
            } catch (Exception e) {

                rt.suspend();
                lb.setText(e.getMessage());
            }

        } else if (ae.getSource() == btPlay) {
            try {
                rt.resume();
            } catch (Exception e) {
                lb.setText(e.getMessage());
            }



        } else if (ae.getSource() == btPause) {
            try {
                rt.suspend();
            } catch (Exception e) {
                lb.setText(e.getMessage());
            }

        }//
        else if (ae.getSource() == btCloud) {

            if (btCloud.getLabel().equals("Cloud")) {
                isCloud = true;

                backbuffer = createImage(width, height);
                backg = backbuffer.getGraphics();
                drawWireframe(backg);

                repaint();

                btCloud.setLabel("Frame");

            } else if (btCloud.getLabel().equals("Frame")) {

                isCloud = false;

                backbuffer = createImage(width, height);
                backg = backbuffer.getGraphics();
                drawWireframe(backg);

                repaint();

                btCloud.setLabel("Cloud");
            }



        }//
        else if (ae.getSource() == btWave) {




            if (btWave.getLabel().equals("Wave")) {
                if (sinWave.getState() == State.NEW) {
                    sinWave.start();
                } else {
                    sinWave.resume();
                }

                btWave.setLabel("Pause");

            } else if (btWave.getLabel().equals("Pause")) {

                sinWave.suspend();

                btWave.setLabel("Wave");



            }


        }//
        else if (ae.getSource() == btMonoChrome) {




            try {
                rt.suspend();
            } catch (Exception e) {
                lb.setText(e.getMessage());
            }

            if (btMonoChrome.getLabel().equals("Mono Chrome")) {
                isMonoChrome = true;

                backbuffer = createImage(width, height);
                backg = backbuffer.getGraphics();
                drawWireframe(backg);

                repaint();

                btMonoChrome.setLabel("Multi Chrome");

            } else if (btMonoChrome.getLabel().equals("Multi Chrome")) {

                isMonoChrome = false;

                backbuffer = createImage(width, height);
                backg = backbuffer.getGraphics();
                drawWireframe(backg);

                repaint();

                btMonoChrome.setLabel("Mono Chrome");



            }


        }
    }

    public void adjustmentValueChanged(AdjustmentEvent ae) {

        int m = vertSB.getValue();

        andar = m;

        int n = horzSB.getValue();

        eye = n;

        backColRed = backR.getValue();
        backColGreen = backG.getValue();
        backColBlue = backB.getValue();


        foreColRed = foreR.getValue();
        foreColGreen = foreG.getValue();
        foreColBlue = foreB.getValue();
        //lb.setText(foreColRed + " " + foreColGreen + " " + foreColBlue);

        backbuffer = createImage(width, height);
        backg = backbuffer.getGraphics();
        drawWireframe(backg);


        longitudnalMovement = longiBar.getValue();
        horizontalMovement = horizBar.getValue();

        repaint();

    }

    public void mouseEntered(MouseEvent e) {
    }

    public void mouseExited(MouseEvent e) {
    }

    public void mouseClicked(MouseEvent e) {
    }

    public void mousePressed(MouseEvent e) {
        mx = e.getX();
        my = e.getY();
        e.consume();
    }

    public void mouseReleased(MouseEvent e) {
    }

    public void mouseMoved(MouseEvent e) {
    }

    public void mouseDragged(MouseEvent e) {
        // get the latest mouse position
        int new_mx = e.getX();
        int new_my = e.getY();

        // adjust angles according to the distance travelled by the mouse
        // since the last event
        azimuth -= new_mx - mx;
        elevation += new_my - my;

        // update the backbuffer
        drawWireframe(backg);

        // update our data
        mx = new_mx;
        my = new_my;

        repaint();
        e.consume();
    }

    public void itemStateChanged(ItemEvent ie) {


        valxFrom = Double.parseDouble(xFrom.getSelectedItem());
        valxTo = Double.parseDouble(xTo.getSelectedItem());
        valzFrom = Double.parseDouble(zFrom.getSelectedItem());
        valzTo = Double.parseDouble(zTo.getSelectedItem());
        String valdesnsityChoiceString = desnsityChoice.getSelectedItem();

        if (valdesnsityChoiceString.equals("High")) {
            valdesnsityChoice = 0.5;
        } else {
            valdesnsityChoice = 1.0;
        }


     
        
        drawWireframe(backg);
        repaint();

    }

    class Rotator extends Thread {

        public void run() {
            int new_mx;
            while (true) {
                //azimuth -= new_mx - mx;
                azimuth = azimuth + 2;
                try {
                    Thread.sleep(200);
                } catch (Exception e) {
                }

                drawWireframe(backg);
                // mx = new_mx;
                repaint();

                //new_mx++;


            }

        }
    }

    public void update(Graphics g) {
        g.drawImage(backbuffer, 0, 0, this);
        showStatus("Elev: " + elevation + " deg, Azim: " + azimuth + " deg");

    }

    public void paint(Graphics g) {

        update(g);
    }

    public double guffyFormulaScriptEngine(String formulaX, String x, String z) {

        try {

            ScriptEngineManager mgr = new ScriptEngineManager();
            ScriptEngine engine = mgr.getEngineByName("JavaScript");



            String expresiionAfterXReplace = formulaX.replaceAll("x", x);
            String expresiionAfterYReplace = expresiionAfterXReplace.replaceAll("z", z);



            lb.setText("Successfully drawn " + tf.getText());

            return (double) engine.eval(expresiionAfterYReplace);

        } catch (Exception e) {
            System.out.println(e.getMessage());
            tf.setText("OOPS ! Unable to draw");
            lb.setText("Error " + e.getMessage());
            return 0;
        }



    }

    class SineWaveGenerator extends Thread {

        public void run() {
            int time = 0;
            double disp = 0.0;


            arrayY = new double[verticesList.size()];
            int counter = 0;
            for (Point3D p : verticesList) {
                arrayY[counter++] = p.y;
            }
            counter = 0;



            while (true) {

                time++;
                for (Point3D p : verticesList) {
                    if (!(p.x == 15 || p.x == -15 || p.y == 15 || p.y == -15 || p.z == 15 || p.z == -15)) {
                        // p.y=guffyFormulaScriptEngine(formula, p.x + "",p.z + "")+Math.sin(p.x+time);
                        p.y = arrayY[counter++] + Math.sin(p.x + time);
                        // p.y=p.y+Math.sin(p.x+time);
                    }
                }

                counter = 0;
                try {
                    Thread.sleep(200);
                } catch (Exception e) {
                }


                drawWireframe(backg);

                repaint();

            }


        }
    }
    // public double guffySineWaveGenerator(String formulaX, String x, String z) {
    // }
}
/*
<applet code="guffyLove" height=800 width=1400>
</applet>
 */
