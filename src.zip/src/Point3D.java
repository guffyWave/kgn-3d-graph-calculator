/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author guffy roX
 */
class Point3D {
   public double x, y, z;
   public Point3D( double X, double Y, double Z ) {
      x = X;  y = Y;  z = Z;
   }


public double getX(){
return x;		
}


public double getY(){
return y;
}

public double getZ(){
return z;
}


}
