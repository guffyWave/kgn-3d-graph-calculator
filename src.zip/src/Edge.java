/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author guffy roX
 */
class Edge {
   public Point3D a, b;
   public Edge( Point3D A, Point3D B ) {
      a = A;  b = B;
   }
}
